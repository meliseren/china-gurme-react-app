import React, { useState, useEffect } from 'react';

import productsData from './db/db.json';


const ProductsEdit = () => {
    const [categories, setCategories] = useState([]);
    const [newCategoryName, setNewCategoryName] = useState('');
    const [addNewCategoryNameModal, setAddNewCategoryNameModal] = useState(false);

    useEffect(() => {
        setCategories(productsData.categories);
    }, []);

    const handleAddCategory = (index = null) => {
        if (index !== null) {
            setNewCategoryName();
            console.log(setNewCategoryName);
        }
        setAddNewCategoryNameModal(true);
    }

    const handleAddCategoryName = () => {
        if (newCategoryName.trim() !== '') {
            const newCategory = {
                id: categories.length + 1,
                name: newCategoryName
            };

            setCategories([...categories, newCategory]);
            setNewCategoryName('');
            setAddNewCategoryNameModal(false);
        } else {
            alert('Kategori adı boş olamaz!');
        }
    }

    const handleCloseModal = () => {
        setAddNewCategoryNameModal(false);
    };

    return (
        <div>
            <button onClick={() => handleAddCategory()}>Kategori Ekle</button>
            <div className='categories-edit'>
                <ul>
                    {categories.map((category) => (
                        <li key={category.id} >
                            {category.name}
                            <button>Düzenle</button>
                            <button>Sil</button>
                        </li>
                    ))}
                </ul>
            </div>
            {
                addNewCategoryNameModal && (
                    <div className="modal">
                        <p>Kategori Ekle</p>
                        <input
                            type="text"
                            placeholder="Kategori Adı"
                            value={newCategoryName}
                            onChange={(e) => {
                                setNewCategoryName(e.target.value);
                            }}
                        />
                        <button onClick={handleAddCategoryName}>Kaydet</button>
                        <button onClick={handleCloseModal}>Kapat</button>
                    </div>
                )
            }
        </div>
    );
};

export default ProductsEdit;
