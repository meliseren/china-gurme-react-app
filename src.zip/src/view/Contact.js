import React from 'react';

const Contact = () => {
    return (
        <div>
            <p>Contact Content</p>
        </div>
    );
}

export default Contact;
